Configuration Instructions for Radar Chart:
1. Go to D:\opt\sasinside\sasva\Lev1\Web\WebServer\htdocs or equivalent
2. put the following files in there:
	d3.min.js
	RadarChart.js

3a.Also create a metadata folder to house the stored process that generates the D3.

3b. You can also use the spk file in the  folder to prepare the EGP program with a stored process. It is available here:
C:\SAS\code\macros\v0_0_1_paM1\Examples\spk\doRadarChartPackage1.spk
The filesystem will require a folder for the stored process called "C:\test"




